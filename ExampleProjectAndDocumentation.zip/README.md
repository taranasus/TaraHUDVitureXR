# VITURE XR Glasses SDK Documentation

This is a comprehensive documentation guide for the VITURE XR Glasses SDK for Android. The documentation is designed to help developers of all levels understand and implement the various features of the VITURE XR Glasses in their Android applications.

## Overview

The VITURE XR Glasses SDK provides a set of APIs to interface with VITURE XR Glasses (Pro, One, and Lite models), enabling developers to access IMU (Inertial Measurement Unit) data for head tracking, control display modes, and manage the device lifecycle.

## Documentation Guides

This documentation is organized into several focused guides:

1. [Getting Started](Documentation/getting-started.md) - Setting up your development environment, creating a new project, and running your first VITURE-enabled app
2. [IMU Data Processing](Documentation/feature-imu-data-processing.md) - Accessing and utilizing head tracking data
3. [Display Mode Control](Documentation/feature-display-mode-control.md) - Managing 2D and 3D display modes
4. [Device Management & Lifecycle](Documentation/feature-device-management.md) - Initializing the SDK, handling permissions, and proper resource management
5. [Event Callbacks](Documentation/feature-event-callbacks.md) - Implementing the callback system to receive device events and data

## Key Features

### IMU Data for Head Tracking

The SDK provides access to the glasses' Inertial Measurement Unit, allowing your applications to respond to the user's head movements in real-time:

- Euler angles (roll, pitch, yaw) for straightforward orientation tracking
- Quaternion data for advanced 3D applications
- Adjustable data frequency (60Hz, 90Hz, 120Hz, or 240Hz)

### Display Mode Control

Control how content is displayed on the glasses:

- Switch between 2D mode (1920×1080) and 3D mode (3840×1080)
- Automatically adjust resolution based on the selected mode
- Handle display mode change events

### Device Lifecycle Management

Properly manage the glasses throughout your application's lifecycle:

- Initialize the USB connection and handle permissions
- Monitor device state (connected/disconnected)
- Properly register and unregister callbacks
- Release resources when they're no longer needed

### Event System

Receive and respond to various events from the glasses:

- IMU data updates
- Display mode changes
- Initialization status
- Device connection events

## Supported Devices

- VITURE Pro XR Glasses
- VITURE One XR Glasses
- VITURE Lite XR Glasses

## System Requirements

- Android 8.0 (API level 28) or higher
- USB-C connection to the VITURE XR Glasses
- Minimum SDK version 28 in your app's build.gradle

## Sample Code

Each documentation guide includes comprehensive code examples to illustrate best practices for implementing specific features. These examples are designed to be easily adapted to your own applications.

## Additional Resources

For more information about the VITURE XR Glasses, visit the [official VITURE website](https://www.viture.com/).

## Contributing

This documentation is designed to be comprehensive, but improvements are always welcome. If you find any issues or have suggestions for enhancements, please contact the development team.

## License

The VITURE XR Glasses SDK is subject to the license terms provided by VITURE. Please refer to the license documentation included with the SDK for more information.
