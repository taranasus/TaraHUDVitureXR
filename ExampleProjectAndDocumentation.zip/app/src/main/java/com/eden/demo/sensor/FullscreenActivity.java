package com.eden.demo.sensor;

import android.annotation.SuppressLint;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.leanback.widget.Util;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Spannable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.CompoundButton;

import com.eden.demo.sensor.databinding.ActivityFullscreenBinding;
import com.viture.sdk.ArCallback;
import com.viture.sdk.ArManager;
import com.viture.sdk.Constants;

import java.nio.ByteBuffer;

/**
 * An example to use the IMU sensor.
 */
public class FullscreenActivity extends AppCompatActivity {
    private static final String TAG = "SensorDemo";

    private Button mBtnView;

    private ActivityFullscreenBinding binding;

    public static final float xStep = 1920f / 64.0f;
    public static final float yStep = 1080f/ 36.0f;
    public float mCurX = 0;
    public float mCurY = 0;
    private int mSdkInitSuccess = -1;
    private float  mLastDegreeX = 0.0f;
    private float  mLastDegreeY = 0.0f;
    private boolean mRegisterd = false;
    private ArManager mArManager;
    private ArCallback mCallback;
    private int mScreenWidth = 0;
    private int mScreenHeight = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityFullscreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        DisplayMetrics dm = getResources().getDisplayMetrics();
        mScreenWidth = dm.widthPixels;
        mScreenHeight = dm.heightPixels;
        mBtnView = binding.fullscreenContent;
        init();
        binding.switchImu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (mSdkInitSuccess == Constants.ERROR_INIT_SUCCESS) {
                    mArManager.setImuOn(b);
                }
            }
        });
        binding.switch3d.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (mSdkInitSuccess == Constants.ERROR_INIT_SUCCESS) {
                    mArManager.set3D(b);
                }
            }
        });
    }

    private void initData() {
        if (mSdkInitSuccess == Constants.ERROR_INIT_SUCCESS) {
            int imuState = mArManager.getImuState();
            int steroState = mArManager.get3DState();
            Log.d(TAG, "get imustate " + imuState + " 3dstate " + steroState);
            binding.switchImu.setChecked(imuState == Constants.STATE_ON);
            binding.switch3d.setChecked(steroState == Constants.STATE_ON);
        }
    }
    private void init() {
        mArManager = ArManager.getInstance(this);

        mSdkInitSuccess = mArManager.init();
        mArManager.setLogOn(true);
        if (mSdkInitSuccess == Constants.ERROR_INIT_SUCCESS) {
            initData();
        }
        mCallback = new ArCallback() {
            @Override
            public void onEvent(int msgId, byte[] event, long l) {
                Log.d(TAG, "onEvent msgid " + msgId + " event " + toHexString(event));

                if (msgId == Constants.EVENT_ID_INIT) {
                    mSdkInitSuccess = byteArrayToInt(event, 0, event.length);
                    Log.d(TAG, "onEvent init " + " event " + mSdkInitSuccess);
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        initData();
                    }
                });
            }

            @Override
            public void onImu(long ts, byte[] imu) {
                int len = imu.length;
                ByteBuffer byteBuffer = ByteBuffer.wrap(imu);
                float eulerRoll = byteBuffer.getFloat(0); //roll --> front axis
                float eulerPitch = byteBuffer.getFloat(4);// pitch -> left axis
                float eulerYaw = byteBuffer.getFloat(8);// yaw --> up axis
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        move(eulerYaw, eulerPitch);
                    }
                });

                if (len >= 36) {
                    float quaternionW = byteBuffer.getFloat(20);
                    float quaternionX = byteBuffer.getFloat(24);
                    float quaternionY = byteBuffer.getFloat(28);
                    float quaternionZ = byteBuffer.getFloat(32);

                }
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        register();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregister();
    }

    private void unregister() {
        mArManager.unregisterCallback(mCallback);
    }

    private void register() {
        mArManager.registerCallback(mCallback);
        resetPostion();
    }

    private void resetPostion() {
        mCurX = mBtnView.getX();
        mCurY = mBtnView.getY();
        mLastDegreeX = 0.0f;
        mLastDegreeY = 0.0f;
    }
    private void move(float x, float y) {
        Log.d(TAG, "move " + x + ":" + y);
        if (mLastDegreeX == 0.0f && mLastDegreeY == 0.0f) {
            mLastDegreeX = x;
            mLastDegreeY = y;
            return ;
        }

        float deltaX = x - mLastDegreeX;
        float deltaY = y - mLastDegreeY;
        mLastDegreeX = x;
        mLastDegreeY = y;

        float moveX = (int)(-xStep * deltaX);
        float moveY = (int)(yStep * deltaY);
        mBtnView.setText("" + x + "\n" + y);
        mCurX = mCurX + moveX;
        mCurY = mCurY + moveY;
        if (mCurX < 0) {
            mCurX = 0;
        }
        if (mCurY < 0) {
            mCurY = 0;
        }
        if (mCurX > mScreenWidth) {
            mCurX = mScreenWidth;
        }
        if (mCurY > mScreenHeight) {
            mCurY = mScreenHeight;
        }
        mBtnView.setX(mCurX);
        mBtnView.setY(mCurY);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mArManager != null) {
            mArManager.release();
        }
    }

    public String toHexString(byte[] paramArrayOfbyte) {
        if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
            return null;
        }
        StringBuilder stringBuilder = new StringBuilder();
        int j = paramArrayOfbyte.length;
        for (int i = 0; i < j; i++) {
            stringBuilder.append(String.format("%02x", new Object[]{Byte.valueOf(paramArrayOfbyte[i])}));
        }
        return stringBuilder.toString();
    }

    public  int byteArrayToInt(byte[] bytes, int offset, int length) {
        if (bytes == null) {
            return 0;
        }
        int value = 0;
        // 由低位到高位
        int len = bytes.length;
        if (offset > len || offset < 0) {
            return 0;
        }
        int right = offset + length;
        if (right > len) {
            right = len;
        }
        for (int i = offset; i < right; i++) {
            int shift = (i - offset) * 8;
            value += (bytes[i] & 0x000000FF) << shift;// 往高位游
        }
        return value;
    }
}